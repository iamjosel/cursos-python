def suma(a,b):
    """
    Descripción de lo que hace esta función:
    lo que hace es sumar dos parametros de tipo entero, es decir, números
    a+b
    """
    total = a+b
    print("resultado de la suma:",total)
    return total
suma(5,8)
help(suma) 