function Route() {
    this.id;
    this.init;
    this.end;
}
/*Clase Route con el nuevo estandar EcmaScript 6 */
/*class Route{
    constructor(){
        this.id;
        this.init;
        this.end;
    }
}
*/