base = 2
altura = 4
area = (base*altura)/2
print(area)
mi_primera_variable = 'Hola platzi'
print("imprimo mi primera variable:",mi_primera_variable)