class UberVan extends Car {
    constructor(license, driver, typeCarAccepted, seatMaterial){
        super(license, driver)
        this.typeCarAccepted = typeCarAccepted;
        this.seatMaterial = seatMaterial;
    }
}