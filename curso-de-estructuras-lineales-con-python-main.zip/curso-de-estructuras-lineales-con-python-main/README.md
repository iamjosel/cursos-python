# curso-de-estructuras-lineales-con-python
