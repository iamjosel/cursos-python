#para importar el zen de python desde la consola es así:
# con este zen es como los valores y principios de la programación en python
import this