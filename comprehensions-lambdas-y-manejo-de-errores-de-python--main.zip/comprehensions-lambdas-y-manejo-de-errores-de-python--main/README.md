# comprenhensions-lambdas-y-manejo-de-errores-de-python-
