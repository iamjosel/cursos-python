#Declaración de un variable
numero = 3
print(numero)
numero1 = 4
print(numero1)
numero2 = 29
numero3 = 88
print("suma de numero1 + numero2 es igual a:",numero1+numero2)