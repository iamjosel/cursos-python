var car = new Car("AW456", new Account("Lio Messi", "Psg"))
car.passenger = 4;
car.printDataCar();

/*llamdando la clase con el nuevo estandar EcmaScript 6 */
/* 
var car = new Car("AWD345", new Account("Lionel Messi", "QWE234"))
car.passenger = 4;
car.printDataCar();
*/
var uberX = new UberX("AW456", new Account("Erling Haaland", "Borussia"), "Nissan", "Versa")
uberX.passenger = 3;
uberX.printDataCar();