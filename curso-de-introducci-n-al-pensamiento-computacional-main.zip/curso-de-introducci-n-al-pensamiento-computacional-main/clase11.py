#fueron apuntes de los flotantes, mirar la lectura en el archivo de apuntes.txt, está interesante
x = 0.0
for i in range(10):
    x += 0.1

if x == 1.0:
    print(f'x = {x}')
else:
    print(f'x != {x}')