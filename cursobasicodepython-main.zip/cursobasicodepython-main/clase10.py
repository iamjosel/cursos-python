#tipos de datos de python

#str o string
from traceback import print_tb


nombre = 'Messi'
print("nombre1:",nombre)
"""Puedo sumar dos strings"""
nombre2 = 'Lío'
print("nombre2:",nombre2)
nombre_completo = nombre+" "+nombre2
print("nombre completo:",nombre_completo)
"""también puedo multiplicar los strings"""
print("multiplicación nombre completo *3:",nombre_completo*3)
#print("multiplicación nombre completo con espacios*3:",nombre_completo*3)
#int o entero
numero = int(2)
print(numero)
#float o decimal, en python el decimal se lo hace con el punto . no con la coma ,
decimal1 = 29.0
print("decimal a mano",decimal1)
decimal = float(29)
print("decimal con float",decimal)
print("transformo de decimal a entero el decimal 29.0")
entero = int(decimal)
print("aquí está",entero)
#Booleanos
es_estudiante = True
print(es_estudiante)
es_trabajador = False
print(es_trabajador)
