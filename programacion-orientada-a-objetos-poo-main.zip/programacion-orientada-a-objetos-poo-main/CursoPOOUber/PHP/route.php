<?php
class Route {
    public $id;
    public $init = array();
    public $end = array();
}
?>