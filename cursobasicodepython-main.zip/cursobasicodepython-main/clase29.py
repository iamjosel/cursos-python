"""
las tuplas son inmutables, no podemos ni agregar ni remover datos.
"""
mi_tupla = (1,2,3,4,5,6,7,8,9,0)
print(mi_tupla)
for i in mi_tupla:
    print(i)
  