#listas
list1 = list()
list2 = ['moto', 4, 'carro', 12345]
list3 = [number**2 for number in range(1,100,3)]
print(list1)
print(list2)
print(list3)
#tuplas
tuple1 = ()
tuple2 = (1234, "hola", 3455)
tuple3 = ("messi", "psg", 234)
print(tuple1)
print(tuple2)
print(tuple3)
#sets
set1 = {1,2,3,4,5}
set2 = set
numbers = [10,20,30,40,50]
set3 = set(numbers)
print(set1)
print(set2)
print(set3)

players1 = {'messi': 'psg', 'dybala':'inter', 'mbappe': 'psg'}
players2 = dict(carro = 2, moto = 'rojo')
print(players1)
print(players2)
