function Payment(){
    this.id;
}

/*Clase Payment con el nuevo estandar EcmaScript 6 */
class Payment {
    constructor() {
        this.id;
    }
}