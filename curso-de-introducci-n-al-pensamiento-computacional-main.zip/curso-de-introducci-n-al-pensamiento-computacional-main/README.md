"# curso-introducci-n-al-pensamiento-computacional" 
"# curso-de-introducci-n-al-pensamiento-computacional" 
