/*para crear el método constructor lo que hago es colocar lo que quiero poner no es necesario colocar el tipo de dato y ya automáticamente  
lo toma como si fuera su método constructor*/
function Account(name, document) {
    this.id;
    this.name = name;
    this.document = document;
    this.email;
    this.password;
}

/*Clase Account con el nuevo estandar EcmaScript 6 */
/*class Account {
    constructor(name, document){
        this.id;
        this.name = name;
        this.document = document;
        this.email;
        this.password;
    }
}
*/