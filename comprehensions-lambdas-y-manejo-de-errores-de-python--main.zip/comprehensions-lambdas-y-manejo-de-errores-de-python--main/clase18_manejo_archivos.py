#Mirar en el archivo de apuntes la clase 18
with open("./ruta/del/apunts.txt", "r") as f: