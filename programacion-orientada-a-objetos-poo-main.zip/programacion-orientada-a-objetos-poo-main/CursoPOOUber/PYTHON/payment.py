class Payment:
    id = int()